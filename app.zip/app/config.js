exports.Prefix = `$`;//your prefix for bot
exports.Token = `ODAxMTIzNDM2MTI5NjgxNDU5.YAcGVw.CdTGHbonZBFhjCfy_UVPcqs2BVg`;//your token 
exports.Color = `BLUE`;//color   of embed